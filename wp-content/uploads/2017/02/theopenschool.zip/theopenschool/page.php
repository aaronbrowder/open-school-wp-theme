<?php

page_template(function() { ?>

   <div class="page">
      <?php the_content(); ?>
   </div>
   
<?php });