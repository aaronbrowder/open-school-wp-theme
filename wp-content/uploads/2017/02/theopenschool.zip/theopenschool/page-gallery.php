<?php 

/*
Template Name: Gallery
*/

page_template(function() { ?>

   <div class="page page-wide">
      <?php the_content(); ?>
   </div>
   
<?php });