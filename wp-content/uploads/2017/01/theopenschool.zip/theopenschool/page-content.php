<div class="page">
    
   <h1 class="page-title">
      <span class="text-light"><?php echo get_page_title_prefix(); ?></span>
      <span class="text-light-green"><?php the_title(); ?></span>
   </h1>
   
   <?php the_content(); ?>
    
</div>
